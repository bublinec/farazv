# Ubuntu webfonts

Unmodified Ubuntu 300, 400, 500 and 700 WOFF2 files copied from the public site's
2026-10-20 design archive. The source manifest records their original URLs as
`https://farazv.sk/static/webfonts/s/ubuntu/v21/…`.

Copyright 2011 Canonical Ltd. Licensed under the Ubuntu Font Licence 1.0.
See [UFL.txt](UFL.txt) and [Canonical’s licence](https://canonical.com/legal/font-licence).
They are self-hosted so the preview does not depend on Google Fonts at runtime.
