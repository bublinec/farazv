"use client";
import { usePathname } from "next/navigation";
import type { ReactNode } from "react";
import { Header } from "./Header";
import { DateRefresh } from "./DateRefresh";
export function SiteShell({
  children,
  footer,
  previewLabel
}: {
  children: ReactNode;
  footer: ReactNode;
  previewLabel?: string;
}) {
  const pathname = usePathname();
  if (pathname === "/admin" || pathname.startsWith("/admin/")) return children;
  return (
    <>
      <Header previewLabel={previewLabel} />
      <main id="main" tabIndex={-1}>
        {children}
      </main>
      {footer}
      <DateRefresh />
    </>
  );
}
