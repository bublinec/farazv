import type { InformationPageDefinition } from "@/content/information";
import { PageHero } from "@/components/ui/PageHero";
import { ReadingCopy, PageLinks, RelatedPages } from "./PageSections";
import { OfficeAside } from "./OfficeAside";
import styles from "./InformationPage.module.css";

export function SacramentPage({ page }: { page: InformationPageDefinition }) {
  const baptism = page.slug.endsWith("sviatost-krstu");
  let preparationType: "baptism" | "marriage" | undefined;
  if (baptism) preparationType = "baptism";
  if (page.slug.endsWith("sviatost-manzelstva")) preparationType = "marriage";

  return (
    <>
      <PageHero
        title={page.title}
        eyebrow={page.eyebrow}
        description={page.introduction}
      />
      <div className={`container ${styles.sacramentLayout}`}>
        <div className={styles.sacramentContent}>
          {baptism ? (
            <div
              className={styles.steps}
              role="group"
              aria-label="Príprava na krst"
            >
              <span>
                <b>01</b> Ozvite sa nám
              </span>
              <span>
                <b>02</b> Pripravte sa spolu
              </span>
              <span>
                <b>03</b> Slávme krst
              </span>
            </div>
          ) : null}
          <ReadingCopy page={page} />
          <PageLinks page={page} />
        </div>
        <OfficeAside preparationType={preparationType} />
      </div>
      <RelatedPages page={page} />
    </>
  );
}
